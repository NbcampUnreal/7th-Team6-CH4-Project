﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Ranged Weapon/RangedWeapons.h"
#include "EquippableComponent.generated.h"


UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class CH4_TEAMPROJECT_API UEquippableComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	// Sets default values for this component's properties
	UEquippableComponent();
	// 데이터 에셋몇개든 관리할함수
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	TMap<int32,class URangedGunDataAsset*> DataAsset;

	//장비 장착함수
	UFUNCTION(BlueprintCallable,Server,Reliable)
	void EquipWeapon(URangedGunDataAsset* WeaponClass);

	//착용중인 무기
	UPROPERTY(Replicated)
	TObjectPtr<ARangedWeapons> CurrentWeapon;
	
	// 컴포넌트에서 발사
	void Fire();
	
	//기억할 총알갯수
	UPROPERTY()
	TMap<TSubclassOf<ARangedWeapons>, int32> WeaponAmmoMemory;
	
	
private:
	
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
};
