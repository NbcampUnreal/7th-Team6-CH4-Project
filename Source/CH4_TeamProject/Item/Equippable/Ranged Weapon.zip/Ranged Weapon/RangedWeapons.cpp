﻿// Fill out your copyright notice in the Description page of Project Settings.

#include "RangedWeapons.h"
#include "DrawDebugHelpers.h"
#include "Components/StaticMeshComponent.h"
#include "Kismet/GameplayStatics.h"
#include "RangedWeaponDataAsset.h"
#include "Net/UnrealNetwork.h"

// Sets default values
ARangedWeapons::ARangedWeapons()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	bReplicates = true;
	
	PrimaryActorTick.bCanEverTick = false;
}

void ARangedWeapons::Server_ApplyDamageToTarget_Implementation(AActor* TargetActor)
{
	if (HasAuthority())
	{
		ProcessDamage(TargetActor);
	}
}

bool ARangedWeapons::Server_ApplyDamageToTarget_Validate(AActor* TargetActor)
{
	return TargetActor != nullptr;
}

void ARangedWeapons::ProcessDamage(AActor* TargetActor)
{
	if (TargetActor)
	{
		// 중요: ApplyDamage를 호출하면 피격자의 TakeDamage가 서버에서 자동 호출됨
		UGameplayStatics::ApplyDamage(
			TargetActor,           
			GunDataAsset->Damage,          
			GetInstigatorController(), 
			this,                  
			UDamageType::StaticClass() 
		);
	}
}

void ARangedWeapons::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(ARangedWeapons, CurrentAmmo);
	DOREPLIFETIME(ARangedWeapons, MaxClip); 
	DOREPLIFETIME(ARangedWeapons, bIsCoolingDown); 
	
}

void ARangedWeapons::SetCurrentAmmo()
{
	if (GunDataAsset)
	{
		CurrentAmmo = GunDataAsset->MaxAmmo;
	}
}

void ARangedWeapons::BeginPlay()
{
	Super::BeginPlay();
	CurrentAmmo = GunDataAsset->MaxAmmo;
}

// Called every frame
void ARangedWeapons::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	{
		GEngine->AddOnScreenDebugMessage(1, 1.f, FColor::Cyan, TEXT("Yahoo: RangedWeapon is Ticking!"));
	}
}

void ARangedWeapons::Server_Fire_Implementation()
{
	if(	bIsCoolingDown || CurrentAmmo <= 0)
	{
		GEngine->AddOnScreenDebugMessage(1, 1.f, FColor::Red,FString::Printf(TEXT("총알이없습니다")));
		return;
	}
	bIsCoolingDown =true;
	TraceShoot();
	Multicast_PlayEffects();
	if (CurrentAmmo >0)
	{
		CurrentAmmo --;
	}
	GEngine->AddOnScreenDebugMessage(-1,
		10,FColor::Red,
		FString::Printf(
			TEXT("남은 총알 %d"),CurrentAmmo)
		,false);
	// 총알 감소및
	// 쿨타임 초기화 등등
	GetWorldTimerManager().SetTimer
	(TimerHandle_FireDelay,
	this,
	&ARangedWeapons::ResetCoolTime, 
	GunDataAsset->FireRate, 
	false);
}

bool ARangedWeapons::Server_Fire_Validate()
{
	//  여기서 펄스면 팅김
	return true;
}

void ARangedWeapons::Multicast_PlayEffects_Implementation()
{
	UE_LOG(LogTemp, Log, TEXT("Fire Effects Played!"));
}
// 시작점
void ARangedWeapons::Fire()
{
	UE_LOG(LogTemp, Error, TEXT("무조건 찍혀야 하는 로그!"));
	if (bIsCoolingDown || CurrentAmmo <= 0)
	{
		UE_LOG(LogTemp, Error, TEXT("총알이 부족해 혹은 딜레이중이야"));
		return;
	}
	bIsCoolingDown = true;
	if (GetOwner() == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("사격 실패: 이 무기의 Owner가 설정되지 않았습니다!"));
		return;
	}
	UE_LOG(LogTemp, Warning, TEXT("1. Fire Called on Client"));
	Server_Fire();	
}

void ARangedWeapons::ProcessReload()
{
	if (!GunDataAsset || CurrentAmmo >= GunDataAsset->MaxAmmo) return;
	if (MaxClip <= 0){ return; }
	int32 AmmoNeeded = GunDataAsset->MaxAmmo - CurrentAmmo;
	int32 AmmoToFill = FMath::Min(AmmoNeeded, MaxClip);
	
	if (HasAuthority()&&GunDataAsset)
	{
		CurrentAmmo += AmmoToFill;
		MaxClip -= AmmoToFill;
	}
}

void ARangedWeapons::Server_ReLoad_Implementation()
{
	if (MaxClip <= 0)
	{
		return;
	}
	ProcessReload();
	
}

bool ARangedWeapons::Server_ReLoad_Validate()
{
	return true;
}

void ARangedWeapons::TraceShoot()
{
	// 서버 권한이 없으면 실행하지 않음 (이중 보안)
	if (!HasAuthority()) return;

	FHitResult Hit;
	FCollisionQueryParams Params;
	Params.AddIgnoredActor(this);
	Params.AddIgnoredActor(GetOwner());

	FVector StartLocation = GetActorLocation();
	FVector EndLocation = StartLocation + (GetActorForwardVector() * GunDataAsset->RangedLength);

	bool bIsHit =  GetWorld()->LineTraceSingleByChannel(Hit, StartLocation, EndLocation, ECC_Visibility, Params);
	FColor LineColor = bIsHit ? FColor::Red : FColor::Green; // 맞으면 빨강, 안 맞으면 초록
    
	DrawDebugLine(
		GetWorld(),
		StartLocation,
		bIsHit ? Hit.ImpactPoint : EndLocation, // 맞은 지점까지만 그리거나 끝까지 그림
		LineColor,
		false,      // Persistent (영구 유지 여부)
		2.0f,       // LifeTime (2초 동안 화면에 남음)
		0,          // DepthPriority
		2.0f        // Thickness (선의 두께)
	);
	if (bIsHit)
	{
		// 서버니까 당당하게 Destroy()나 데미지 처리를 합니다.
		if (Hit.GetActor())
		{
			Server_ApplyDamageToTarget(Hit.GetActor());
		}
	}
	
}

int32 ARangedWeapons::GetMaxAmmo () const
{
	if (GunDataAsset)
	{
		return GunDataAsset->MaxAmmo;
	}
	return 0;
}

void ARangedWeapons::OnRep_FireReady() 
{
	
}

void ARangedWeapons::ResetCoolTime()
{
	bIsCoolingDown = false;
	
	UE_LOG(LogTemp, Error, TEXT("Yahoo: 쿨다운 해제됨!"));
}

void ARangedWeapons::AddMaxClip(int32 AmmoItem)
{
	if (!HasAuthority())
	{
		return;
	}
	MaxClip += AmmoItem; 
}
